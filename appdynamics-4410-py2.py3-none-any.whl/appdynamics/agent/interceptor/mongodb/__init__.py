# Copyright (c) AppDynamics, Inc., and its affiliates
# 2016
# All Rights Reserved

from __future__ import unicode_literals

from .pymongo import intercept_pymongo

__all__ = ['intercept_pymongo']
